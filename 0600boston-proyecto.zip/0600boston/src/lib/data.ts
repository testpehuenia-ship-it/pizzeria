export interface IngredienteDecorativo {
  id: string;
  nombre: string;
  icono: string;
  color: string;
  imagenUrl?: string;
  posiciones: Array<{ x: number; y: number; rot: number; scale?: number }>;
  oculto?: boolean;
}

export interface PizzaDataType {
  id: string;
  nombre: string;
  descripcion: string;
  precio4: number;
  precio8: number;
  imagen?: string;
  ingredientesDecorables?: IngredienteDecorativo[];
  oculto?: boolean;
}

export interface BebidaDataType {
  id: string;
  nombre: string;
  precio: number;
  categoria: "gaseosa" | "agua" | "cerveza";
  imagenUrl?: string;
  descripcion?: string;
  oculto?: boolean;
}

export interface AderezoDataType {
  id: string;
  nombre: string;
  precio: number;
}

export const PIZZAS_DATA: PizzaDataType[] = [
  {
    id: "napolitana",
    nombre: "Napolitana",
    descripcion: "Salsa de tomate, muzzarella, rodajas de tomate natural, albahaca, ajo y aceitunas",
    precio4: 12800,
    precio8: 25500,
    imagen: "🍅",
    ingredientesDecorables: [
      {
        id: "tomate-rodajas",
        nombre: "Rodajas de Tomate",
        icono: "🍅",
        color: "#ef4444",
        imagenUrl: "/images/ingredientes/tomate_rodaja.png",
        posiciones: [
          { x: 32, y: 35, rot: 15, scale: 1.1 },
          { x: 68, y: 34, rot: -20, scale: 1.05 },
          { x: 30, y: 68, rot: 45, scale: 1.1 },
          { x: 70, y: 66, rot: -10, scale: 1.0 },
          { x: 50, y: 50, rot: 5, scale: 1.15 },
        ],
      },
      {
        id: "albahaca",
        nombre: "Albahaca Fresca",
        icono: "🌿",
        color: "#15803d",
        imagenUrl: "/images/ingredientes/albahaca.png",
        posiciones: [
          { x: 42, y: 28, rot: -30, scale: 0.9 },
          { x: 74, y: 48, rot: 40, scale: 0.95 },
          { x: 48, y: 72, rot: 15, scale: 0.9 },
          { x: 26, y: 52, rot: -45, scale: 0.85 },
          { x: 58, y: 42, rot: 25, scale: 0.95 },
        ],
      },
      {
        id: "ajo-picado",
        nombre: "Ajo Picado",
        icono: "🧄",
        color: "#fef08a",
        imagenUrl: "/images/ingredientes/ajo.png",
        posiciones: [
          { x: 38, y: 46, rot: 10, scale: 0.7 },
          { x: 62, y: 58, rot: -15, scale: 0.75 },
          { x: 52, y: 32, rot: 50, scale: 0.7 },
        ],
      },
      {
        id: "aceitunas",
        nombre: "Aceitunas Verdes",
        icono: "🫒",
        color: "#65a30d",
        imagenUrl: "/images/ingredientes/aceitunas.png",
        posiciones: [
          { x: 24, y: 38, rot: 0, scale: 0.85 },
          { x: 76, y: 32, rot: 20, scale: 0.85 },
          { x: 72, y: 76, rot: -15, scale: 0.85 },
          { x: 28, y: 78, rot: 35, scale: 0.85 },
        ],
      },
      {
        id: "oliva",
        nombre: "Aceite de Oliva",
        icono: "✨",
        color: "#eab308",
        posiciones: [
          { x: 50, y: 50, rot: 0, scale: 1.4 },
        ],
      },
    ],
  },
  {
    id: "muzzarella",
    nombre: "Muzzarella",
    descripcion: "Salsa de tomate casera, abundante muzzarella fundida, aceitunas y orégano",
    precio4: 11500,
    precio8: 22200,
    imagen: "🧀",
    ingredientesDecorables: [
      {
        id: "aceitunas",
        nombre: "Aceitunas Verdes",
        icono: "🫒",
        color: "#65a30d",
        imagenUrl: "/images/ingredientes/aceitunas.png",
        posiciones: [
          { x: 30, y: 32, rot: 10 },
          { x: 70, y: 32, rot: -20 },
          { x: 30, y: 70, rot: 30 },
          { x: 70, y: 70, rot: -10 },
          { x: 50, y: 50, rot: 5 },
          { x: 50, y: 22, rot: 45 },
          { x: 50, y: 78, rot: -35 },
          { x: 22, y: 50, rot: 15 },
        ],
      },
      {
        id: "oregano",
        nombre: "Orégano Molido",
        icono: "🌱",
        color: "#166534",
        posiciones: [
          { x: 40, y: 40, rot: 0, scale: 0.8 },
          { x: 60, y: 42, rot: 25, scale: 0.8 },
          { x: 42, y: 62, rot: -20, scale: 0.8 },
          { x: 62, y: 60, rot: 15, scale: 0.8 },
        ],
      },
      {
        id: "oliva",
        nombre: "Aceite de Oliva",
        icono: "✨",
        color: "#eab308",
        posiciones: [
          { x: 50, y: 50, rot: 0, scale: 1.3 },
        ],
      },
    ],
  },
  {
    id: "jamon-y-morrones",
    nombre: "Jamón y Morrones",
    descripcion: "Salsa de tomate, muzzarella, jamón cocido en fetas y morrones asados",
    precio4: 13800,
    precio8: 27500,
    imagen: "🥓",
    ingredientesDecorables: [
      {
        id: "jamon",
        nombre: "Fetas de Jamón",
        icono: "🥓",
        color: "#f472b6",
        imagenUrl: "/images/ingredientes/jamon.png",
        posiciones: [
          { x: 34, y: 36, rot: -15, scale: 1.2 },
          { x: 66, y: 35, rot: 20, scale: 1.2 },
          { x: 32, y: 68, rot: 35, scale: 1.2 },
          { x: 68, y: 65, rot: -25, scale: 1.2 },
          { x: 50, y: 50, rot: 10, scale: 1.25 },
        ],
      },
      {
        id: "morrones",
        nombre: "Tiras de Morrón",
        icono: "🌶️",
        color: "#dc2626",
        imagenUrl: "/images/ingredientes/morron.png",
        posiciones: [
          { x: 42, y: 28, rot: 45, scale: 1.0 },
          { x: 72, y: 48, rot: -30, scale: 1.0 },
          { x: 48, y: 72, rot: 60, scale: 1.0 },
          { x: 26, y: 52, rot: -45, scale: 1.0 },
        ],
      },
      {
        id: "aceitunas",
        nombre: "Aceitunas Verdes",
        icono: "🫒",
        color: "#65a30d",
        imagenUrl: "/images/ingredientes/aceitunas.png",
        posiciones: [
          { x: 50, y: 36, rot: 0 },
          { x: 64, y: 54, rot: 15 },
          { x: 36, y: 54, rot: -20 },
        ],
      },
    ],
  },
  {
    id: "fugazza",
    nombre: "Fugazza con Muzzarella",
    descripcion: "Cebolla dorada en juliana, muzzarella, oliva, aceitunas y orégano",
    precio4: 11800,
    precio8: 23500,
    imagen: "🧅",
    ingredientesDecorables: [
      {
        id: "cebolla",
        nombre: "Cebolla en Juliana",
        icono: "🧅",
        color: "#fed7aa",
        imagenUrl: "/images/ingredientes/cebolla.png",
        posiciones: [
          { x: 35, y: 35, rot: 30, scale: 1.1 },
          { x: 65, y: 35, rot: -40, scale: 1.15 },
          { x: 35, y: 65, rot: -20, scale: 1.1 },
          { x: 65, y: 65, rot: 45, scale: 1.15 },
          { x: 50, y: 50, rot: 15, scale: 1.2 },
        ],
      },
      {
        id: "oregano",
        nombre: "Orégano",
        icono: "🌱",
        color: "#166534",
        posiciones: [
          { x: 45, y: 42, rot: 10, scale: 0.8 },
          { x: 55, y: 58, rot: -15, scale: 0.8 },
        ],
      },
      {
        id: "aceitunas",
        nombre: "Aceitunas",
        icono: "🫒",
        color: "#65a30d",
        imagenUrl: "/images/ingredientes/aceitunas.png",
        posiciones: [
          { x: 28, y: 48, rot: 0 },
          { x: 72, y: 48, rot: 25 },
        ],
      },
    ],
  },
  {
    id: "calabresa",
    nombre: "Calabresa",
    descripcion: "Salsa de tomate, muzzarella y abundante longaniza calabresa crocante",
    precio4: 13800,
    precio8: 27500,
    imagen: "🍕",
    ingredientesDecorables: [
      {
        id: "longaniza",
        nombre: "Rodajas Calabresa",
        icono: "🥩",
        color: "#b91c1c",
        imagenUrl: "/images/ingredientes/calabresa.png",
        posiciones: [
          { x: 30, y: 30, rot: 15, scale: 1.0 },
          { x: 70, y: 30, rot: -25, scale: 1.0 },
          { x: 30, y: 70, rot: 40, scale: 1.0 },
          { x: 70, y: 70, rot: -10, scale: 1.0 },
          { x: 50, y: 50, rot: 5, scale: 1.1 },
          { x: 50, y: 25, rot: 30, scale: 0.95 },
          { x: 50, y: 75, rot: -20, scale: 0.95 },
          { x: 25, y: 50, rot: 45, scale: 0.95 },
          { x: 75, y: 50, rot: -35, scale: 0.95 },
        ],
      },
      {
        id: "aceitunas",
        nombre: "Aceitunas Negras",
        icono: "🫒",
        color: "#1f2937",
        imagenUrl: "/images/ingredientes/aceitunas.png",
        posiciones: [
          { x: 40, y: 40, rot: 0 },
          { x: 60, y: 60, rot: 20 },
        ],
      },
    ],
  },
  {
    id: "margarita",
    nombre: "Margarita Gourmet",
    descripcion: "Salsa de tomate, muzzarella, rodajas de tomate, parmesano y albahaca fresca",
    precio4: 12500,
    precio8: 25000,
    imagen: "🌿",
    ingredientesDecorables: [
      {
        id: "tomates",
        nombre: "Tomate Natural",
        icono: "🍅",
        color: "#ef4444",
        imagenUrl: "/images/ingredientes/tomate_rodaja.png",
        posiciones: [
          { x: 35, y: 35, rot: 20, scale: 1.05 },
          { x: 65, y: 35, rot: -15, scale: 1.05 },
          { x: 35, y: 65, rot: -30, scale: 1.05 },
          { x: 65, y: 65, rot: 25, scale: 1.05 },
        ],
      },
      {
        id: "parmesano",
        nombre: "Queso Parmesano",
        icono: "🧀",
        color: "#fde047",
        posiciones: [
          { x: 50, y: 50, rot: 0, scale: 1.3 },
          { x: 40, y: 60, rot: 45, scale: 0.9 },
        ],
      },
      {
        id: "albahaca",
        nombre: "Hojas de Albahaca",
        icono: "🌿",
        color: "#15803d",
        imagenUrl: "/images/ingredientes/albahaca.png",
        posiciones: [
          { x: 50, y: 35, rot: -10, scale: 1.0 },
          { x: 35, y: 50, rot: 30, scale: 0.95 },
          { x: 65, y: 50, rot: -45, scale: 0.95 },
          { x: 50, y: 65, rot: 15, scale: 1.0 },
        ],
      },
    ],
  },
  {
    id: "rucula-y-jamon-crudo",
    nombre: "Rúcula y Jamón Crudo",
    descripcion: "Muzzarella, abundante rúcula fresca, jamón crudo serrano y lluvia de parmesano",
    precio4: 16500,
    precio8: 32500,
    imagen: "🥩",
    ingredientesDecorables: [
      {
        id: "jamon-crudo",
        nombre: "Jamón Crudo",
        icono: "🥓",
        color: "#be123c",
        imagenUrl: "/images/ingredientes/jamon.png",
        posiciones: [
          { x: 32, y: 34, rot: -20, scale: 1.2 },
          { x: 68, y: 36, rot: 25, scale: 1.2 },
          { x: 34, y: 66, rot: 40, scale: 1.2 },
          { x: 66, y: 64, rot: -35, scale: 1.2 },
          { x: 50, y: 50, rot: 15, scale: 1.25 },
        ],
      },
      {
        id: "rucula",
        nombre: "Rúcula Fresca",
        icono: "🥗",
        color: "#166534",
        posiciones: [
          { x: 40, y: 30, rot: 30, scale: 1.1 },
          { x: 60, y: 40, rot: -25, scale: 1.1 },
          { x: 35, y: 55, rot: 45, scale: 1.1 },
          { x: 60, y: 65, rot: -15, scale: 1.1 },
          { x: 50, y: 45, rot: 5, scale: 1.15 },
        ],
      },
      {
        id: "parmesano",
        nombre: "Escamas Parmesano",
        icono: "🧀",
        color: "#fef08a",
        posiciones: [
          { x: 45, y: 48, rot: 12, scale: 0.8 },
          { x: 55, y: 52, rot: -18, scale: 0.8 },
        ],
      },
    ],
  },
  {
    id: "especial",
    nombre: "Especial 0600",
    descripcion: "Salsa de tomate, muzzarella, jamón cocido, huevo duro picado y tiras de morrón",
    precio4: 16000,
    precio8: 32000,
    imagen: "⭐",
    ingredientesDecorables: [
      {
        id: "jamon",
        nombre: "Jamón Cocido",
        icono: "🥓",
        color: "#f472b6",
        imagenUrl: "/images/ingredientes/jamon.png",
        posiciones: [
          { x: 35, y: 35, rot: -15, scale: 1.1 },
          { x: 65, y: 35, rot: 20, scale: 1.1 },
          { x: 35, y: 65, rot: 30, scale: 1.1 },
          { x: 65, y: 65, rot: -20, scale: 1.1 },
        ],
      },
      {
        id: "huevo",
        nombre: "Huevo Duro",
        icono: "🥚",
        color: "#fef08a",
        imagenUrl: "/images/ingredientes/huevo_rodaja.png",
        posiciones: [
          { x: 50, y: 50, rot: 0, scale: 1.1 },
          { x: 50, y: 30, rot: 25, scale: 0.95 },
          { x: 50, y: 70, rot: -15, scale: 0.95 },
        ],
      },
      {
        id: "morrones",
        nombre: "Morrones",
        icono: "🌶️",
        color: "#dc2626",
        imagenUrl: "/images/ingredientes/morron.png",
        posiciones: [
          { x: 30, y: 50, rot: -30, scale: 0.95 },
          { x: 70, y: 50, rot: 40, scale: 0.95 },
        ],
      },
    ],
  },
  {
    id: "roquefort",
    nombre: "Cuatro Quesos & Roquefort",
    descripcion: "Salsa blanca, muzzarella, abundante roquefort intenso, oliva y ajo",
    precio4: 15000,
    precio8: 30000,
    imagen: "🧀",
    ingredientesDecorables: [
      {
        id: "roquefort",
        nombre: "Queso Roquefort",
        icono: "🧀",
        color: "#0284c7",
        posiciones: [
          { x: 35, y: 35, rot: 15, scale: 1.0 },
          { x: 65, y: 35, rot: -20, scale: 1.0 },
          { x: 35, y: 65, rot: 35, scale: 1.0 },
          { x: 65, y: 65, rot: -10, scale: 1.0 },
          { x: 50, y: 50, rot: 45, scale: 1.1 },
        ],
      },
      {
        id: "aceitunas",
        nombre: "Aceitunas Negras",
        icono: "🫒",
        color: "#1e293b",
        imagenUrl: "/images/ingredientes/aceitunas.png",
        posiciones: [
          { x: 26, y: 50, rot: 0 },
          { x: 74, y: 50, rot: 15 },
        ],
      },
    ],
  },
  {
    id: "jamon-y-muzzarella",
    nombre: "Jamón y Muzzarella",
    descripcion: "Salsa de tomate casera, muzzarella, jamón cocido seleccionado y oliva",
    precio4: 13300,
    precio8: 26500,
    imagen: "🧀",
    ingredientesDecorables: [
      {
        id: "jamon",
        nombre: "Fetas de Jamón",
        icono: "🥓",
        color: "#f472b6",
        imagenUrl: "/images/ingredientes/jamon.png",
        posiciones: [
          { x: 35, y: 35, rot: -15, scale: 1.15 },
          { x: 65, y: 35, rot: 25, scale: 1.15 },
          { x: 35, y: 65, rot: 40, scale: 1.15 },
          { x: 65, y: 65, rot: -30, scale: 1.15 },
          { x: 50, y: 50, rot: 10, scale: 1.2 },
        ],
      },
      {
        id: "aceitunas",
        nombre: "Aceitunas Verdes",
        icono: "🫒",
        color: "#65a30d",
        imagenUrl: "/images/ingredientes/aceitunas.png",
        posiciones: [
          { x: 50, y: 32, rot: 0 },
          { x: 50, y: 68, rot: 15 },
        ],
      },
    ],
  },
  {
    id: "fugazza-mixta",
    nombre: "Fugazza Mixta",
    descripcion: "Cebolla blanca y morada caramelizada, muzzarella y aceite de oliva",
    precio4: 11500,
    precio8: 22500,
    imagen: "🧅",
    ingredientesDecorables: [
      {
        id: "cebolla-blanca",
        nombre: "Cebolla Blanca",
        icono: "🧅",
        color: "#fed7aa",
        imagenUrl: "/images/ingredientes/cebolla.png",
        posiciones: [
          { x: 35, y: 35, rot: 20, scale: 1.1 },
          { x: 65, y: 65, rot: -25, scale: 1.1 },
          { x: 50, y: 50, rot: 45, scale: 1.15 },
        ],
      },
      {
        id: "cebolla-morada",
        nombre: "Cebolla Morada",
        icono: "🧅",
        color: "#c084fc",
        imagenUrl: "/images/ingredientes/cebolla.png",
        posiciones: [
          { x: 65, y: 35, rot: -30, scale: 1.1 },
          { x: 35, y: 65, rot: 35, scale: 1.1 },
        ],
      },
      {
        id: "aceitunas",
        nombre: "Aceitunas",
        icono: "🫒",
        color: "#65a30d",
        imagenUrl: "/images/ingredientes/aceitunas.png",
        posiciones: [
          { x: 50, y: 28, rot: 0 },
          { x: 50, y: 72, rot: 20 },
        ],
      },
    ],
  },
];

export const ADEREZOS_DATA: AderezoDataType[] = [
  { id: "oregano", nombre: "Orégano", precio: 0 },
  { id: "aceitunas", nombre: "Aceitunas extra", precio: 0 },
  { id: "oliva", nombre: "Aceite de Oliva", precio: 0 },
  { id: "parmesano", nombre: "Queso Parmesano", precio: 0 },
  { id: "aji-molido", nombre: "Ají Molido", precio: 0 },
  { id: "ajo", nombre: "Ajo picado", precio: 0 },
];

export const BEBIDAS_DATA: BebidaDataType[] = [
  {
    id: "coca-500",
    nombre: "Coca-Cola 500ml",
    precio: 1500,
    categoria: "gaseosa",
    imagenUrl: "🥤",
    descripcion: "Botella individual 500ml bien fría",
  },
  {
    id: "coca-15l",
    nombre: "Coca-Cola 1.5L",
    precio: 2800,
    categoria: "gaseosa",
    imagenUrl: "🍾",
    descripcion: "Tamaño familiar 1.5L original",
  },
  {
    id: "sprite-500",
    nombre: "Sprite 500ml",
    precio: 1500,
    categoria: "gaseosa",
    imagenUrl: "🥤",
    descripcion: "Lima-limón refrescante 500ml",
  },
  {
    id: "sprite-15l",
    nombre: "Sprite 1.5L",
    precio: 2800,
    categoria: "gaseosa",
    imagenUrl: "🍾",
    descripcion: "Tamaño familiar 1.5L lima-limón",
  },
  {
    id: "fanta-500",
    nombre: "Fanta 500ml",
    precio: 1500,
    categoria: "gaseosa",
    imagenUrl: "🥤",
    descripcion: "Sabor naranja intenso 500ml",
  },
  {
    id: "agua-500",
    nombre: "Agua Mineral 500ml",
    precio: 1000,
    categoria: "agua",
    imagenUrl: "💧",
    descripcion: "Agua pura de manantial sin gas",
  },
  {
    id: "agua-15l",
    nombre: "Agua Mineral 1.5L",
    precio: 1800,
    categoria: "agua",
    imagenUrl: "🍶",
    descripcion: "Botella 1.5L familiar sin gas",
  },
  {
    id: "quilmes-473",
    nombre: "Cerveza Quilmes 473ml",
    precio: 2200,
    categoria: "cerveza",
    imagenUrl: "🍺",
    descripcion: "Lata 473ml Clásica rubia helada",
  },
  {
    id: "stella-473",
    nombre: "Cerveza Stella Artois 473ml",
    precio: 2800,
    categoria: "cerveza",
    imagenUrl: "🍺",
    descripcion: "Lata 473ml Premium belga",
  },
  {
    id: "patagonia-473",
    nombre: "Cerveza Patagonia 473ml",
    precio: 3200,
    categoria: "cerveza",
    imagenUrl: "🍻",
    descripcion: "Lata 473ml Amber Lager artesanal",
  },
];

export const WHATSAPP_NUMERO = "5492942661000";
export const WHATSAPP_NUMERO_LOCAL = "02942661000";
export const WHATSAPP_DISPLAY = "02942-661000";
